﻿
using System.Collections.Generic;
using RimWorld;

using HarmonyLib;
using Verse;
using System.Linq;

using System.Text;
using System.Reflection;


namespace yayoEnding
{
    public class harmonyPatch : Mod
    {
        public harmonyPatch(ModContentPack content) : base(content)
        {
            var harmony = new Harmony("yayoEnding");
            harmony.PatchAll();
        }
    }

    [HarmonyPatch(typeof(DefGenerator), "GenerateImpliedDefs_PreResolve")]
    public class Patch_DefGenerator_GenerateImpliedDefs_PreResolve
    {
        public static void Prefix()
        {
            core.patchDef();
        }

    }


    [HarmonyPatch(typeof(ShipCountdown), "CountdownEnded")]
    internal class patch_ShipCountdown_CountdownEnded
    {
        private static FieldInfo f_shipRoot = AccessTools.Field(typeof(ShipCountdown), "shipRoot");
        private static AccessTools.FieldRef<Building> s_shipRoot = AccessTools.StaticFieldRefAccess<Building>(f_shipRoot);

        [HarmonyPostfix]
        static bool Prefix()
        {
            Building shipRoot = s_shipRoot.Invoke();

            if (shipRoot != null && shipRoot.def.defName == "yy_teleporter")
            {
                List<Building> list = new List<Building>();
                List<Pawn> list2 = new List<Pawn>();
                list.Add(shipRoot);
                StringBuilder stringBuilder = new StringBuilder();
                foreach (Pawn p in shipRoot.Map.mapPawns.FreeColonists)
                {
                    stringBuilder.AppendLine("   " + p.LabelCap);
                    ++Find.StoryWatcher.statsRecord.colonistsLaunched;
                    TaleRecorder.RecordTale(TaleDefOf.LaunchedShip, (object)p);
                    list2.Add(p);
                }
                foreach (Pawn p in list2)
                    p.Destroy();

                GameVictoryUtility.ShowCredits(GameVictoryUtility.MakeEndCredits((string)"yayoEnding_intro".Translate(), (string)"yayoEnding_ending".Translate(), stringBuilder.ToString()));
                foreach (Thing thing in list)
                    thing.Destroy();
                

                return false;
            }
            else
            {
                return true;
            }
            
        }
    }



    // 탄약 카테고리 보이기
    [HarmonyPatch(typeof(ThingFilter), "SetFromPreset")]
    internal class patch_ThingFilter_SetFromPreset
    {
        [HarmonyPostfix]
        static bool Prefix(ThingFilter __instance, StorageSettingsPreset preset)
        {
            if (preset == StorageSettingsPreset.DefaultStockpile)
            {
                __instance.SetAllow(ThingCategoryDef.Named("yy_gem_category"), true);
            }
            return true;
        }
    }





}