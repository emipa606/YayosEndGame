﻿using System;
using System.Collections.Generic;
using Verse;
using Verse.AI;
using RimWorld;

namespace yayoEnding
{
    public class JobDriver_OperateGemMaker : JobDriver
    {
        public override bool TryMakePreToilReservations(bool errorOnFailed) => this.pawn.Reserve(this.job.targetA, this.job, errorOnFailed: errorOnFailed);

        protected override IEnumerable<Toil> MakeNewToils()
        {
            JobDriver_OperateGemMaker f = this;
            f.FailOnDespawnedNullOrForbidden<JobDriver_OperateGemMaker>(TargetIndex.A);
            f.FailOnBurningImmobile<JobDriver_OperateGemMaker>(TargetIndex.A);
            f.FailOnThingHavingDesignation<JobDriver_OperateGemMaker>(TargetIndex.A, DesignationDefOf.Uninstall);
            f.FailOn<JobDriver_OperateGemMaker>((Func<bool>)(() => !this.job.targetA.Thing.TryGetComp<CompGemMaker>().CanDrillNow()));
            yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.InteractionCell);
            Toil work = new Toil();
            work.tickAction = (Action)(() =>
            {
                Pawn actor = work.actor;
                ((ThingWithComps)actor.CurJob.targetA.Thing).GetComp<CompGemMaker>().DrillWorkDone(actor);
                actor.skills.Learn(SkillDefOf.Mining, 0.065f);
            });
            work.defaultCompleteMode = ToilCompleteMode.Never;
            work.WithEffect(EffecterDefOf.DisabledByEMP, TargetIndex.A);
            work.FailOnCannotTouch<Toil>(TargetIndex.A, PathEndMode.InteractionCell);
            work.activeSkill = (Func<SkillDef>)(() => SkillDefOf.Mining);
            yield return work;
        }
    }
}
