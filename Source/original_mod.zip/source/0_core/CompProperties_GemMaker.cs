﻿using Verse;

namespace yayoEnding
{
    public class CompProperties_GemMaker : CompProperties
    {
        public CompProperties_GemMaker() => this.compClass = typeof(CompGemMaker);
    }
}
