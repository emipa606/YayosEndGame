﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Verse;
using RimWorld;

namespace yayoEnding
{
    public class Building_Teleporter : Building
    {

        public override IEnumerable<Gizmo> GetGizmos()
        {
            foreach (Gizmo gizmo in base.GetGizmos())
            {
                yield return gizmo;
            }
            IEnumerator<Gizmo> enumerator = null;
            foreach (Gizmo gizmo2 in ShipUtility.ShipStartupGizmos(this))
            {
                yield return gizmo2;
            }
            enumerator = null;
            Command_Action command_Action = new Command_Action();
            command_Action.action = new Action(this.TryLaunch);
            command_Action.defaultLabel = "yayoEnding_CommandTeleporterLaunch".Translate();
            command_Action.defaultDesc = "yayoEnding_CommandTeleporterLaunchDesc".Translate();

            CompHibernatable comp = this.TryGetComp<CompHibernatable>();
            if (comp != null && comp.State == HibernatableStateDefOf.Hibernating)
            {
                command_Action.Disable("yayoEnding_energyChargeRequired".Translate());
            }
            else if (comp != null && !comp.Running)
            {
                command_Action.Disable("yayoEnding_energyChargeRequired".Translate());
            }
               

            if (ShipCountdown.CountingDown)
            {
                command_Action.Disable(null);
            }
            command_Action.hotKey = KeyBindingDefOf.Misc1;
            command_Action.icon = ContentFinder<Texture2D>.Get("UI/Commands/LaunchShip", true);
            yield return command_Action;
            yield break;
            yield break;
        }

        public void ForceLaunch()
        {
            ShipCountdown.InitiateCountdown(this);
            if (base.Spawned)
            {
                QuestUtility.SendQuestTargetSignals(base.Map.Parent.questTags, "LaunchedShip");
            }
        }

        private void TryLaunch()
        {
            this.ForceLaunch();
        }
    }
}
