﻿using System.Collections.Generic;
using Verse;
using Verse.AI;
using RimWorld;

namespace yayoEnding
{
    public class WorkGiver_GemMaker : WorkGiver_Scanner
    {
        public override ThingRequest PotentialWorkThingRequest => ThingRequest.ForDef(ThingDefOf.yy_biomeExtractor);

        public override PathEndMode PathEndMode => PathEndMode.InteractionCell;

        public override Danger MaxPathDanger(Pawn pawn) => Danger.Deadly;

        public override bool ShouldSkip(Pawn pawn, bool forced = false)
        {
            List<Building> buildingsColonist = pawn.Map.listerBuildings.allBuildingsColonist;
            for (int index = 0; index < buildingsColonist.Count; ++index)
            {
                Building building = buildingsColonist[index];
                if (building.def == ThingDefOf.yy_biomeExtractor)
                {
                    CompPowerTrader comp = building.GetComp<CompPowerTrader>();
                    if ((comp == null || comp.PowerOn) && building.Map.designationManager.DesignationOn((Thing)building, DesignationDefOf.Uninstall) == null)
                        return false;
                }
            }
            return true;
        }

        public override bool HasJobOnThing(Pawn pawn, Thing t, bool forced = false) => t.Faction == pawn.Faction && t is Building building && (!building.IsForbidden(pawn) && pawn.CanReserve((LocalTargetInfo)(Thing)building, ignoreOtherReservations: forced)) && (building.TryGetComp<CompGemMaker>().CanDrillNow() && building.Map.designationManager.DesignationOn((Thing)building, DesignationDefOf.Uninstall) == null && !building.IsBurning());

        public override Job JobOnThing(Pawn pawn, Thing t, bool forced = false) => JobMaker.MakeJob(yayoEnding.JobDefOf.OperateGemMaker, (LocalTargetInfo)t, 1500, true);
    }
}
