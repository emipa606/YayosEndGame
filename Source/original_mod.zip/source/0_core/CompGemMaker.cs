﻿using System;
using UnityEngine;
using Verse;
using RimWorld;

namespace yayoEnding
{
    public class CompGemMaker : ThingComp
    {
        private CompPowerTrader powerComp;
        private float portionProgress;
        private float portionYieldPct;
        private int lastUsedTick = -99999;
        private const float WorkPerPortionBase = 2000f * 60f;
        private ThingDef gemDef
        {
            get
            {
                ThingDef t = ThingDef.Named($"yy_gem_{this.parent.Map.Biome.defName}");

                return t;
            }
        }

        [Obsolete("Use WorkPerPortionBase constant directly.")]
        public static float WorkPerPortionCurrentDifficulty => WorkPerPortionBase;

        public float ProgressToNextPortionPercent => this.portionProgress / WorkPerPortionBase;

        public override void PostSpawnSetup(bool respawningAfterLoad) => this.powerComp = this.parent.TryGetComp<CompPowerTrader>();

        public override void PostExposeData()
        {
            Scribe_Values.Look<float>(ref this.portionProgress, "portionProgress");
            Scribe_Values.Look<float>(ref this.portionYieldPct, "portionYieldPct");
            Scribe_Values.Look<int>(ref this.lastUsedTick, "lastUsedTick");
        }

        public void DrillWorkDone(Pawn driller)
        {
            float statValue = driller.GetStatValue(StatDefOf.DeepDrillingSpeed) * core.extractSpeed;
            this.portionProgress += statValue;
            this.portionYieldPct += (float)((double)statValue * (double)driller.GetStatValue(StatDefOf.MiningYield) / WorkPerPortionBase);
            this.lastUsedTick = Find.TickManager.TicksGame;
            if ((double)this.portionProgress <= WorkPerPortionBase)
                return;
            this.TryProducePortion(this.portionYieldPct);
            this.portionProgress = 0.0f;
            this.portionYieldPct = 0.0f;
        }

        public override void PostDeSpawn(Map map)
        {
            this.portionProgress = 0.0f;
            this.portionYieldPct = 0.0f;
            this.lastUsedTick = -99999;
        }

        private void TryProducePortion(float yieldPct)
        {
            Map m = this.parent.Map;
            Thing thing = ThingMaker.MakeThing(gemDef);
            thing.stackCount = Rand.Range(3, 9);
            GenPlace.TryPlaceThing(thing, this.parent.InteractionCell, m, ThingPlaceMode.Near);
        }

        public bool CanDrillNow()
        {
            if (this.powerComp != null && !this.powerComp.PowerOn)
                return false;
            return true;
        }

        public bool UsedLastTick() => this.lastUsedTick >= Find.TickManager.TicksGame - 1;

        public override string CompInspectStringExtra()
        {
            if (!this.parent.Spawned)
                return (string)null;
            return (string)("yayoEnding_resource".Translate() + ": " + gemDef.label + "\n" + "ProgressToNextPortion".Translate() + ": " + this.ProgressToNextPortionPercent.ToStringPercent("F0"));
        }
    }
}
